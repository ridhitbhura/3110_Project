(* TODO: set the value below, then delete this TODO comment. *)
let hours_worked = 16