 (* import from another module involving board? *)


type t = {
  hp : int;
  gold: int; 
  (* properties: property list ;
  faction: faction ; *)
  (* weapon: weapon  *)
  location: int 
}